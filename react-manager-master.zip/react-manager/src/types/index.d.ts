interface Window {
  BMapGL: {
    [propName: string]: any
  }
  BMapGLLib: any
  BMapLib: any
}
