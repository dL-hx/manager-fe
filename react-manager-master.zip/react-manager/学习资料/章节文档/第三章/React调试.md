## React 调试

**console 调试**

- console.log

- console.info

- console.warn

- console.error

- console.time() & console.timeEnd()

- console.count()

**debugger调试**

**chrome断点调试**

**chrome条件断点**

**HTML节点复制**

- 选中节点，使用 `$0`复制

**JavaScript对象复制**

- copy函数

**接口调试**

#### 掘进文章

[2022了还不会调试吗？ - 掘金](https://juejin.cn/post/7124104703884918798)
