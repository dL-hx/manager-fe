/* eslint-disable no-unused-vars */
/* eslint-disable @typescript-eslint/no-inferrable-types */
// 类型：string

const name: string = 'jack'

const age: number = 30

const isTrue: boolean = true

let a: undefined

const b: null = null

const user: object = {}

const big: bigint = 100n

const sym: symbol = Symbol('hepan')

export default {}
